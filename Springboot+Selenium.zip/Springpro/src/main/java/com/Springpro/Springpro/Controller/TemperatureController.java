package com.Springpro.Springpro.Controller;

import com.Springpro.Springpro.Entity.Temperature;
import com.Springpro.Springpro.Service.TemperatureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@RestController
//@RequestMapping("/addTemperature")
public class TemperatureController {

    @Autowired
    private TemperatureService temperatureService;

    @PostMapping("/addTemperature")
    public ResponseEntity<Temperature> createTemperature(@RequestBody Temperature temperature) {
        if (temperature.getDateTime() == null) {
            temperature.setDateTime(LocalDateTime.now());
        }
        Temperature savedTemperature = temperatureService.saveDetails(temperature);
        return new ResponseEntity<>(savedTemperature, HttpStatus.CREATED);
    }
    @GetMapping("/getTempById/{id}")
    public Temperature fetchById(@PathVariable Long id){
        return temperatureService.getTempById(id);
    }

    @DeleteMapping("/DeleteTempById/{id}")
    public String deleteTemp(@PathVariable Long id){

        return temperatureService.deleteTemp(id);
    }


}
