package com.Springpro.Springpro.Repository;

import com.Springpro.Springpro.Entity.Temperature;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TemperatureRepo extends JpaRepository<Temperature,Long> {

}
