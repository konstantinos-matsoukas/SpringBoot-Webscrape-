package com.Springpro.Springpro.Service;

import com.Springpro.Springpro.Entity.Temperature;
import com.Springpro.Springpro.Repository.TemperatureRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TemperatureService {

    @Autowired
    private TemperatureRepo temperatureRepo;

    public Temperature saveDetails(Temperature temperature){


        return temperatureRepo.save(temperature);
    }

    public Temperature getTempById(Long id){
        return temperatureRepo.findById(id).orElse(null);
    }

    public String deleteTemp(Long id){
        if(temperatureRepo.existsById(id)){
            temperatureRepo.deleteById(id);
            return "delete" +id;
        }else{
           return  "id doesnt exist";
        }

    }
}
