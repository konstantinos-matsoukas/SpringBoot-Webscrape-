package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) throws InterruptedException, IOException {
        System.setProperty("webdriver.chrome.driver", "H:\\Downloads\\chromedriver-win64\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.okairos.gr");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        WebElement acceptCookiesButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@class, 'fc-cta-consent')]")));
        acceptCookiesButton.click();


        WebElement searchBar = driver.findElement(By.id("q"));
        searchBar.sendKeys("Αθηνα");
        searchBar.submit();

        WebElement linkElement = wait.until(ExpectedConditions.elementToBeClickable(By.partialLinkText("Αθήνα")));
        linkElement.click();

        WebElement linkElement2 = wait.until(ExpectedConditions.elementToBeClickable(By.partialLinkText("Τώρα")));
        linkElement2.click();

        // Getting temeperature
        WebElement tempElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("temp")));
        String tempText = tempElement.getText();

        // Clearing the output from symbos and making into an int
        String temperature = tempText.replaceAll("[^\\d]", "");  // This keeps only the digits

        Float tempValue = Float.valueOf(temperature);
        //LocalDateTime time = LocalDateTime.now();

        System.out.println("The temperature is: " + tempValue + "º");
        Thread.sleep(5000);
        driver.quit();


        //POST REQUEST
        // Format the LocalDateTime to a string (e.g., "2024-09-12T10:15:30")
        try {


            LocalDateTime time = LocalDateTime.now();

            // Format the LocalDateTime to a string (e.g., "2024-09-12T10:15:30")
            DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
            String formattedTime = time.format(formatter);

            // Define the URL of the Spring Boot application endpoint
            URL url = new URL("http://localhost:8080/addTemperature");  // Replace with your actual URL

            // Open a connection to the URL
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setDoOutput(true);

            // Create the JSON payload
            String jsonInputString = String.format("{\"dateTime\": \"%s\", \"temperature\": %.1f}", formattedTime, tempValue);

            // Write the JSON payload to the output stream
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonInputString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            // Get the response from the server
            int responseCode = connection.getResponseCode();
            System.out.println("Response Code: " + responseCode);

            // Close the connection
            connection.disconnect();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}






